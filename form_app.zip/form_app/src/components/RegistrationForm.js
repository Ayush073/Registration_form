// src/components/RegistrationForm.js

import React from 'react';
import { useForm } from 'react-hook-form';
import '../styles/RegistrationForm.css';

const RegistrationForm = () => {
  const { register, handleSubmit, formState: { errors } } = useForm();

  const onSubmit = (data) => {
    // You can handle the registration logic here
    console.log('Form data submitted:', data);
  };

  return (
    <div>
      <h2>Registration Form</h2>
      <form onSubmit={handleSubmit(onSubmit)}>
        <label>
          First Name:
          <input
            type="text"
            {...register('firstName', { required: 'First Name is required' })}
          />
          {errors.firstName && <p>{errors.firstName.message}</p>}
        </label>
        <br />

        <label>
          Last Name:
          <input
            type="text"
            {...register('lastName', { required: 'Last Name is required' })}
          />
          {errors.lastName && <p>{errors.lastName.message}</p>}
        </label>
        <br />

        <label>
          Email:
          <input
            type="email"
            {...register('email', {
              required: 'Email is required',
              pattern: {
                value: /\S+@\S+\.\S+/,
                message: 'Invalid email address',
              },
            })}
          />
          {errors.email && <p>{errors.email.message}</p>}
        </label>
        <br />

        <label>
          Password:
          <input
            type="password"
            {...register('password', {
              required: 'Password is required',
              minLength: {
                value: 8,
                message: 'Password must be at least 8 characters long',
              },
            })}
          />
          {errors.password && <p>{errors.password.message}</p>}
        </label>
        <br />

        <button type="submit">Register</button>
      </form>
    </div>
  );
};

export default RegistrationForm;
